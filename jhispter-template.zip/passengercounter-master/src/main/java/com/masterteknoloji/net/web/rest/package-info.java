/**
 * Spring MVC REST controllers.
 */
package com.masterteknoloji.net.web.rest;
