/**
 * JPA domain objects.
 */
package com.masterteknoloji.net.domain;
