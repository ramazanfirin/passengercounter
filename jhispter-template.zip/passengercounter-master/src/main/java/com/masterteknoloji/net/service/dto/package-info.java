/**
 * Data Transfer Objects.
 */
package com.masterteknoloji.net.service.dto;
