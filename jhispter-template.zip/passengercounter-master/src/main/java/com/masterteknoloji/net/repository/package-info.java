/**
 * Spring Data JPA repositories.
 */
package com.masterteknoloji.net.repository;
