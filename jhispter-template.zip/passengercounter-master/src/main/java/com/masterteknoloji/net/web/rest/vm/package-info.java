/**
 * View Models used by Spring MVC REST controllers.
 */
package com.masterteknoloji.net.web.rest.vm;
