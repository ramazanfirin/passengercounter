/**
 * Service layer beans.
 */
package com.masterteknoloji.net.service;
