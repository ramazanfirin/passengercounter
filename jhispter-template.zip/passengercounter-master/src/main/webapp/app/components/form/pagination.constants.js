(function() {
    'use strict';

    angular
        .module('passengercounter2App')
        .constant('paginationConstants', {
            'itemsPerPage': 20
        });
})();
